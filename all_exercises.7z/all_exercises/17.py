#Calculate the sum of value of key a and value of key b and print it out
d = {"a": 1, "b": 2}
print(d["b"] + d["a"])
