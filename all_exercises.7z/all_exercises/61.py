#Create a program that prints Hello every 2 seconds
import time

while True:
    print("Hello")
    time.sleep(2)
