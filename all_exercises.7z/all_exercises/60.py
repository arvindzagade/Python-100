#Create a program that prints Hello repeatedly.

while 1 < 2:
    print("Hello")
