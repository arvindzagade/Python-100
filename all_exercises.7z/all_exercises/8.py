#Complete the script so that it prints out the letter i using negative indexing
letters = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"]
print(letters[-2])
