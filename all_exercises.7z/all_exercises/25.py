#Make a script that prints out letters of English alphabet from a to z
import string

for letter in string.ascii_lowercase:
    print(letter)


#Video question
